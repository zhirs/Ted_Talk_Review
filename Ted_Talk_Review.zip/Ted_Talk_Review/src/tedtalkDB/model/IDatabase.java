package tedtalkDB.model;

public interface IDatabase {
	public boolean checkCredentials(String user, String pass);
}