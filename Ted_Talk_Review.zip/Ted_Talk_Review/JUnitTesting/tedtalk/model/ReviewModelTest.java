package tedtalk.model;
import org.junit.Before;
import org.junit.After;
import org.junit.Test;
import static org.junit.Assert.assertTrue;
import tedtalk.model.ReviewModel;
public class ReviewModelTest {
	
}
